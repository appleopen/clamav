#!/bin/sh
../sigtool/sigtool -V >/dev/null
