#!/bin/sh
../freshclam/freshclam --config-file=$srcdir/test-freshclam.conf -V >/dev/null
